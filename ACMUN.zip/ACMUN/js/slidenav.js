function slidenav() {
    var nav = document.querySelector('.nav');

    nav.classList.toggle('slidenav');
}